import { useState } from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { FiHeart, FiBookmark, FiMessageCircle, FiEye, FiDownload, FiFileText } from 'react-icons/fi';
import { interactionsAPI } from '../services/api';
import { useAuth } from '../context/AuthContext';
import toast from 'react-hot-toast';
import './NoteCard.css';

const subjectColors = {
  'Mathematics': '#7c3aed',
  'Computer Science': '#06b6d4',
  'Physics': '#f59e0b',
  'Chemistry': '#10b981',
  'Biology': '#ef4444',
  'History': '#8b5cf6',
  'Economics': '#f97316',
  'Literature': '#ec4899',
  'Data Science': '#14b8a6',
  'Engineering': '#6366f1',
};

const formatSize = (bytes) => {
  if (!bytes) return '';
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1048576) return `${(bytes / 1024).toFixed(0)} KB`;
  return `${(bytes / 1048576).toFixed(1)} MB`;
};

const NoteCard = ({ note, onUpdate }) => {
  const { isAuthenticated } = useAuth();
  const [liked, setLiked] = useState(note.isLiked || false);
  const [saved, setSaved] = useState(note.isSaved || false);
  const [likesCount, setLikesCount] = useState(note.likesCount || 0);
  const [savesCount, setSavesCount] = useState(note.savesCount || 0);
  const [loading, setLoading] = useState(false);

  const color = subjectColors[note.subject] || '#7c3aed';

  const handleLike = async (e) => {
    e.preventDefault();
    if (!isAuthenticated) return toast.error('Please login to like notes');
    if (loading) return;
    setLoading(true);
    try {
      if (liked) {
        await interactionsAPI.unlike(note._id);
        setLiked(false);
        setLikesCount(prev => Math.max(0, prev - 1));
      } else {
        await interactionsAPI.like(note._id);
        setLiked(true);
        setLikesCount(prev => prev + 1);
      }
    } catch {
      toast.error('Failed to update like');
    }
    setLoading(false);
  };

  const handleSave = async (e) => {
    e.preventDefault();
    if (!isAuthenticated) return toast.error('Please login to save notes');
    if (loading) return;
    setLoading(true);
    try {
      if (saved) {
        await interactionsAPI.unsave(note._id);
        setSaved(false);
        setSavesCount(prev => Math.max(0, prev - 1));
        toast.success('Removed from saved');
      } else {
        await interactionsAPI.save(note._id);
        setSaved(true);
        setSavesCount(prev => prev + 1);
        toast.success('Note saved!');
      }
    } catch {
      toast.error('Failed to update save');
    }
    setLoading(false);
  };

  return (
    <motion.div
      className="note-card glass-card"
      whileHover={{ y: -4 }}
      transition={{ duration: 0.2 }}
    >
      {/* Color accent top bar */}
      <div className="note-card-accent" style={{ background: color }} />

      <Link to={`/notes/${note._id}`} className="note-card-body">
        {/* Header */}
        <div className="note-card-header">
          <span className="note-subject-badge" style={{ background: `${color}22`, color, borderColor: `${color}44` }}>
            {note.subject}
          </span>
          <span className="note-file-type">
            <FiFileText size={12} /> {note.fileType?.toUpperCase() || 'PDF'}
          </span>
        </div>

        {/* Title */}
        <h3 className="note-title">{note.title}</h3>

        {/* Topic */}
        <p className="note-topic">📌 {note.topic}</p>

        {/* Description */}
        {note.description && (
          <p className="note-description">{note.description}</p>
        )}

        {/* Tags */}
        {note.tags?.length > 0 && (
          <div className="note-tags">
            {note.tags.slice(0, 3).map(tag => (
              <span key={tag} className="note-tag">#{tag}</span>
            ))}
          </div>
        )}

        {/* Author */}
        <div className="note-author">
          <div className="avatar avatar-sm">{note.uploadedBy?.name?.charAt(0) || 'U'}</div>
          <span>{note.uploadedBy?.name || 'Unknown'}</span>
          {note.uploadedBy?.role === 'admin' && <span className="admin-badge">Admin</span>}
        </div>
      </Link>

      {/* Footer Actions */}
      <div className="note-card-footer">
        <div className="note-stats">
          <span className="stat">
            <FiEye size={14} /> {note.views || 0}
          </span>
          <span className="stat">
            <FiMessageCircle size={14} /> {note.commentsCount || 0}
          </span>
          {note.fileSize && <span className="stat">{formatSize(note.fileSize)}</span>}
        </div>

        <div className="note-actions">
          <button
            className={`action-btn ${liked ? 'liked' : ''}`}
            onClick={handleLike}
            title={liked ? 'Unlike' : 'Like'}
          >
            <FiHeart size={16} fill={liked ? 'currentColor' : 'none'} />
            <span>{likesCount}</span>
          </button>
          <button
            className={`action-btn ${saved ? 'saved' : ''}`}
            onClick={handleSave}
            title={saved ? 'Unsave' : 'Save'}
          >
            <FiBookmark size={16} fill={saved ? 'currentColor' : 'none'} />
          </button>
          <a
            href={`http://localhost:5000${note.fileUrl}`}
            target="_blank"
            rel="noopener noreferrer"
            className="action-btn"
            onClick={e => e.stopPropagation()}
            title="Download"
          >
            <FiDownload size={16} />
          </a>
        </div>
      </div>
    </motion.div>
  );
};

export default NoteCard;
