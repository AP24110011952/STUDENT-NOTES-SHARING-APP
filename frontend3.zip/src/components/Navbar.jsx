import { useState, useEffect } from 'react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { FiHome, FiBook, FiUpload, FiGrid, FiUser, FiLogOut, FiMenu, FiX, FiShield, FiBookmark } from 'react-icons/fi';
import { useAuth } from '../context/AuthContext';
import './Navbar.css';

const Navbar = () => {
  const { user, isAuthenticated, isAdmin, logout } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const [scrolled, setScrolled] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const [dropdownOpen, setDropdownOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  useEffect(() => setMenuOpen(false), [location.pathname]);

  const handleLogout = () => {
    logout();
    navigate('/');
    setDropdownOpen(false);
  };

  const isActive = (path) => location.pathname === path;

  const navLinks = [
    { to: '/', label: 'Home', icon: <FiHome /> },
    { to: '/notes', label: 'Browse Notes', icon: <FiBook /> },
    ...(isAuthenticated ? [
      { to: '/upload', label: 'Upload', icon: <FiUpload /> },
      { to: '/dashboard', label: 'Dashboard', icon: <FiGrid /> },
    ] : []),
    ...(isAdmin ? [{ to: '/admin', label: 'Admin', icon: <FiShield /> }] : [])
  ];

  return (
    <nav className={`navbar ${scrolled ? 'scrolled' : ''}`}>
      <div className="navbar-inner">
        {/* Logo */}
        <Link to="/" className="navbar-logo">
          <span className="logo-icon">📚</span>
          <span className="logo-text">NoteShare<span className="logo-accent">Pro</span></span>
        </Link>

        {/* Desktop Nav */}
        <div className="nav-links">
          {navLinks.map(link => (
            <Link key={link.to} to={link.to} className={`nav-link ${isActive(link.to) ? 'active' : ''}`}>
              {link.icon}
              {link.label}
            </Link>
          ))}
        </div>

        {/* Auth area */}
        <div className="nav-auth">
          {isAuthenticated ? (
            <div className="user-menu" onClick={() => setDropdownOpen(!dropdownOpen)}>
              <div className="avatar avatar-sm">{user?.name?.charAt(0).toUpperCase()}</div>
              <span className="user-name">{user?.name?.split(' ')[0]}</span>
              <AnimatePresence>
                {dropdownOpen && (
                  <motion.div
                    className="dropdown"
                    initial={{ opacity: 0, y: -10, scale: 0.95 }}
                    animate={{ opacity: 1, y: 0, scale: 1 }}
                    exit={{ opacity: 0, y: -10, scale: 0.95 }}
                    transition={{ duration: 0.15 }}
                  >
                    <Link to="/profile" className="dropdown-item" onClick={() => setDropdownOpen(false)}>
                      <FiUser /> My Profile
                    </Link>
                    <Link to="/dashboard" className="dropdown-item" onClick={() => setDropdownOpen(false)}>
                      <FiGrid /> Dashboard
                    </Link>
                    <Link to="/dashboard?tab=saved" className="dropdown-item" onClick={() => setDropdownOpen(false)}>
                      <FiBookmark /> Saved Notes
                    </Link>
                    {isAdmin && (
                      <Link to="/admin" className="dropdown-item admin-item" onClick={() => setDropdownOpen(false)}>
                        <FiShield /> Admin Panel
                      </Link>
                    )}
                    <div className="dropdown-divider" />
                    <button className="dropdown-item danger" onClick={handleLogout}>
                      <FiLogOut /> Logout
                    </button>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          ) : (
            <div className="auth-buttons">
              <Link to="/login" className="btn btn-secondary btn-sm">Login</Link>
              <Link to="/register" className="btn btn-primary btn-sm">Sign Up</Link>
            </div>
          )}

          {/* Mobile menu toggle */}
          <button className="menu-toggle" onClick={() => setMenuOpen(!menuOpen)} aria-label="Toggle menu">
            {menuOpen ? <FiX /> : <FiMenu />}
          </button>
        </div>
      </div>

      {/* Mobile Menu */}
      <AnimatePresence>
        {menuOpen && (
          <motion.div
            className="mobile-menu"
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
          >
            {navLinks.map(link => (
              <Link key={link.to} to={link.to} className={`mobile-nav-link ${isActive(link.to) ? 'active' : ''}`}>
                {link.icon} {link.label}
              </Link>
            ))}
            {!isAuthenticated && (
              <div className="mobile-auth">
                <Link to="/login" className="btn btn-secondary" style={{ width: '100%' }}>Login</Link>
                <Link to="/register" className="btn btn-primary" style={{ width: '100%' }}>Sign Up</Link>
              </div>
            )}
            {isAuthenticated && (
              <button className="mobile-nav-link danger" onClick={handleLogout}>
                <FiLogOut /> Logout
              </button>
            )}
          </motion.div>
        )}
      </AnimatePresence>

      {/* Backdrop for dropdown */}
      {dropdownOpen && <div className="nav-backdrop" onClick={() => setDropdownOpen(false)} />}
    </nav>
  );
};

export default Navbar;
