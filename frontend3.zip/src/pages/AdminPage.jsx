import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { FiUsers, FiFileText, FiMessageCircle, FiHeart, FiTrash2, FiCheckCircle, FiShield, FiExternalLink } from 'react-icons/fi';
import { adminAPI } from '../services/api';
import { Link } from 'react-router-dom';
import toast from 'react-hot-toast';
import './AdminPage.css';

const AdminPage = () => {
  const [tab, setTab] = useState('overview');
  const [stats, setStats] = useState(null);
  const [users, setUsers] = useState([]);
  const [notes, setNotes] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchData = async () => {
      setLoading(true);
      try {
        const [statsRes, usersRes, notesRes] = await Promise.all([
          adminAPI.getStats(),
          adminAPI.getUsers(),
          adminAPI.getNotes()
        ]);
        setStats(statsRes.data.data);
        setUsers(usersRes.data.data);
        setNotes(notesRes.data.data);
      } catch (err) {
        toast.error('Failed to load admin data');
      }
      setLoading(false);
    };
    fetchData();
  }, []);

  const handleDeleteUser = async (id, name) => {
    if (!window.confirm(`Delete user "${name}"? This cannot be undone.`)) return;
    try {
      await adminAPI.deleteUser(id);
      setUsers(prev => prev.filter(u => u._id !== id));
      toast.success('User deleted');
    } catch { toast.error('Failed to delete user'); }
  };

  const handleRoleChange = async (id, newRole) => {
    try {
      await adminAPI.updateRole(id, newRole);
      setUsers(prev => prev.map(u => u._id === id ? { ...u, role: newRole } : u));
      toast.success(`Role updated to ${newRole}`);
    } catch { toast.error('Failed to update role'); }
  };

  const handleDeleteNote = async (id) => {
    if (!window.confirm('Delete this note?')) return;
    try {
      await adminAPI.deleteNote(id);
      setNotes(prev => prev.filter(n => n._id !== id));
      toast.success('Note deleted');
    } catch { toast.error('Failed to delete note'); }
  };

  const handleApprove = async (id) => {
    try {
      await adminAPI.approveNote(id);
      setNotes(prev => prev.map(n => n._id === id ? { ...n, status: 'approved' } : n));
      toast.success('Note approved');
    } catch { toast.error('Failed to approve note'); }
  };

  if (loading) return (
    <div className="page-wrapper loading-container">
      <div className="spinner" />
      <p>Loading admin data...</p>
    </div>
  );

  const tabs = [
    { key: 'overview', label: 'Overview', icon: <FiShield /> },
    { key: 'notes', label: 'Notes', icon: <FiFileText /> },
    { key: 'users', label: 'Users', icon: <FiUsers /> }
  ];

  return (
    <div className="admin-page page-wrapper">
      <div className="container">
        <motion.div className="admin-header" initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }}>
          <div>
            <h1>🛡️ Admin Panel</h1>
            <p>Manage content, users, and platform health</p>
          </div>
        </motion.div>

        {/* Tabs */}
        <div className="admin-tabs">
          {tabs.map(t => (
            <button
              key={t.key}
              className={`admin-tab ${tab === t.key ? 'active' : ''}`}
              onClick={() => setTab(t.key)}
            >
              {t.icon} {t.label}
            </button>
          ))}
        </div>

        {/* Overview */}
        {tab === 'overview' && stats && (
          <motion.div key="overview" initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
            <div className="admin-stats-grid">
              {[
                { icon: <FiUsers />, value: stats.totalUsers, label: 'Total Students', color: '#7c3aed' },
                { icon: <FiFileText />, value: stats.totalNotes, label: 'Approved Notes', color: '#06b6d4' },
                { icon: <FiMessageCircle />, value: stats.totalComments, label: 'Comments', color: '#10b981' },
                { icon: <FiHeart />, value: stats.totalLikes, label: 'Total Likes', color: '#ef4444' }
              ].map((s, i) => (
                <motion.div
                  key={s.label}
                  className="admin-stat-card glass-card"
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ delay: i * 0.08 }}
                >
                  <div className="admin-stat-icon" style={{ background: `${s.color}22`, color: s.color }}>{s.icon}</div>
                  <div>
                    <div className="admin-stat-value">{s.value}</div>
                    <div className="admin-stat-label">{s.label}</div>
                  </div>
                </motion.div>
              ))}
            </div>

            <div className="admin-two-col">
              {/* Recent Users */}
              <div className="glass-card admin-section">
                <h2>Recent Users</h2>
                <table className="admin-table">
                  <thead><tr><th>Name</th><th>Email</th><th>Joined</th></tr></thead>
                  <tbody>
                    {stats.recentUsers?.map(u => (
                      <tr key={u._id}>
                        <td><div className="avatar avatar-sm" style={{ display: 'inline-flex', marginRight: '0.5rem' }}>{u.name.charAt(0)}</div>{u.name}</td>
                        <td style={{ color: 'var(--text-muted)', fontSize: '0.8rem' }}>{u.email}</td>
                        <td style={{ color: 'var(--text-muted)', fontSize: '0.8rem' }}>{new Date(u.createdAt).toLocaleDateString()}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              {/* Recent Notes */}
              <div className="glass-card admin-section">
                <h2>Recent Notes</h2>
                <table className="admin-table">
                  <thead><tr><th>Title</th><th>By</th><th>Status</th></tr></thead>
                  <tbody>
                    {stats.recentNotes?.map(n => (
                      <tr key={n._id}>
                        <td style={{ maxWidth: '180px', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{n.title}</td>
                        <td style={{ color: 'var(--text-muted)', fontSize: '0.8rem' }}>{n.uploadedBy?.name}</td>
                        <td>
                          <span className={`badge ${n.status === 'approved' ? 'badge-green' : n.status === 'pending' ? 'badge-orange' : 'badge-red'}`}>
                            {n.status}
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </motion.div>
        )}

        {/* Notes Management */}
        {tab === 'notes' && (
          <motion.div key="notes" initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
            <div className="glass-card admin-section">
              <h2>All Notes ({notes.length})</h2>
              <div className="table-scroll">
                <table className="admin-table">
                  <thead>
                    <tr>
                      <th>Title</th>
                      <th>Subject</th>
                      <th>Uploaded By</th>
                      <th>Date</th>
                      <th>Status</th>
                      <th>Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {notes.map(note => (
                      <tr key={note._id}>
                        <td>
                          <span style={{ fontWeight: 600, color: 'var(--text-primary)', maxWidth: '200px', display: 'block', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                            {note.title}
                          </span>
                        </td>
                        <td><span className="badge badge-purple">{note.subject}</span></td>
                        <td style={{ fontSize: '0.8rem', color: 'var(--text-secondary)' }}>{note.uploadedBy?.name}</td>
                        <td style={{ fontSize: '0.8rem', color: 'var(--text-muted)' }}>{new Date(note.createdAt).toLocaleDateString()}</td>
                        <td>
                          <span className={`badge ${note.status === 'approved' ? 'badge-green' : note.status === 'pending' ? 'badge-orange' : 'badge-red'}`}>
                            {note.status}
                          </span>
                        </td>
                        <td>
                          <div className="action-row">
                            <Link to={`/notes/${note._id}`} className="action-icon-btn view" title="View">
                              <FiExternalLink />
                            </Link>
                            {note.status === 'pending' && (
                              <button className="action-icon-btn approve" onClick={() => handleApprove(note._id)} title="Approve">
                                <FiCheckCircle />
                              </button>
                            )}
                            <button className="action-icon-btn delete" onClick={() => handleDeleteNote(note._id)} title="Delete">
                              <FiTrash2 />
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </motion.div>
        )}

        {/* Users Management */}
        {tab === 'users' && (
          <motion.div key="users" initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
            <div className="glass-card admin-section">
              <h2>All Users ({users.length})</h2>
              <div className="table-scroll">
                <table className="admin-table">
                  <thead>
                    <tr>
                      <th>Name</th>
                      <th>Email</th>
                      <th>Role</th>
                      <th>Joined</th>
                      <th>Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {users.map(u => (
                      <tr key={u._id}>
                        <td>
                          <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                            <div className="avatar avatar-sm">{u.name.charAt(0)}</div>
                            <span style={{ fontWeight: 600 }}>{u.name}</span>
                          </div>
                        </td>
                        <td style={{ fontSize: '0.8rem', color: 'var(--text-secondary)' }}>{u.email}</td>
                        <td>
                          <select
                            className="role-select"
                            value={u.role}
                            onChange={e => handleRoleChange(u._id, e.target.value)}
                          >
                            <option value="student">Student</option>
                            <option value="admin">Admin</option>
                          </select>
                        </td>
                        <td style={{ fontSize: '0.8rem', color: 'var(--text-muted)' }}>{new Date(u.createdAt).toLocaleDateString()}</td>
                        <td>
                          <button className="action-icon-btn delete" onClick={() => handleDeleteUser(u._id, u.name)}>
                            <FiTrash2 />
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </motion.div>
        )}
      </div>
    </div>
  );
};

export default AdminPage;
