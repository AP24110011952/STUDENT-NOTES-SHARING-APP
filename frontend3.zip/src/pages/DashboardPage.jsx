import { useState, useEffect } from 'react';
import { useSearchParams, Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { FiGrid, FiBookmark, FiUpload, FiHeart, FiEye, FiTrash2, FiExternalLink } from 'react-icons/fi';
import { notesAPI } from '../services/api';
import { useAuth } from '../context/AuthContext';
import toast from 'react-hot-toast';
import './DashboardPage.css';

const DashboardPage = () => {
  const { user } = useAuth();
  const [searchParams, setSearchParams] = useSearchParams();
  const tab = searchParams.get('tab') || 'my-notes';
  const [myNotes, setMyNotes] = useState([]);
  const [savedNotes, setSavedNotes] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchData = async () => {
      setLoading(true);
      try {
        const [myRes, savedRes] = await Promise.all([
          notesAPI.getMyNotes(),
          notesAPI.getSaved()
        ]);
        setMyNotes(myRes.data.data);
        setSavedNotes(savedRes.data.data);
      } catch (err) {
        console.error('Dashboard fetch error:', err);
      }
      setLoading(false);
    };
    fetchData();
  }, []);

  const handleDelete = async (id) => {
    if (!window.confirm('Delete this note?')) return;
    try {
      await notesAPI.delete(id);
      setMyNotes(prev => prev.filter(n => n._id !== id));
      toast.success('Note deleted');
    } catch { toast.error('Failed to delete'); }
  };

  const totalLikes = myNotes.reduce((acc, n) => acc + (n.likesCount || 0), 0);
  const totalViews = myNotes.reduce((acc, n) => acc + (n.views || 0), 0);

  const tabs = [
    { key: 'my-notes', label: 'My Notes', icon: <FiGrid />, count: myNotes.length },
    { key: 'saved', label: 'Saved Notes', icon: <FiBookmark />, count: savedNotes.length }
  ];

  return (
    <div className="dashboard-page page-wrapper">
      <div className="container">
        {/* Welcome header */}
        <motion.div
          className="dashboard-header"
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
        >
          <div className="welcome-row">
            <div className="avatar avatar-xl">{user?.name?.charAt(0)}</div>
            <div>
              <h1>Welcome, {user?.name?.split(' ')[0]}! 👋</h1>
              <p>{user?.email}</p>
              <span className="badge badge-purple">{user?.role}</span>
            </div>
          </div>

          {/* Stats row */}
          <div className="dashboard-stats">
            {[
              { icon: <FiUpload />, value: myNotes.length, label: 'Notes Uploaded', color: '#7c3aed' },
              { icon: <FiHeart />, value: totalLikes, label: 'Total Likes', color: '#ef4444' },
              { icon: <FiEye />, value: totalViews, label: 'Total Views', color: '#06b6d4' },
              { icon: <FiBookmark />, value: savedNotes.length, label: 'Saved Notes', color: '#10b981' }
            ].map((s, i) => (
              <motion.div
                key={s.label}
                className="dash-stat glass-card"
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: i * 0.1 }}
              >
                <div className="dash-stat-icon" style={{ background: `${s.color}22`, color: s.color }}>
                  {s.icon}
                </div>
                <div>
                  <div className="dash-stat-value">{s.value}</div>
                  <div className="dash-stat-label">{s.label}</div>
                </div>
              </motion.div>
            ))}
          </div>
        </motion.div>

        {/* Tabs */}
        <div className="dash-tabs">
          {tabs.map(t => (
            <button
              key={t.key}
              className={`dash-tab ${tab === t.key ? 'active' : ''}`}
              onClick={() => setSearchParams({ tab: t.key })}
            >
              {t.icon} {t.label}
              <span className="tab-count">{t.count}</span>
            </button>
          ))}
          <Link to="/upload" className="btn btn-primary btn-sm" style={{ marginLeft: 'auto' }}>
            <FiUpload /> Upload New
          </Link>
        </div>

        {/* Content */}
        {loading ? (
          <div className="loading-container">
            <div className="spinner" />
            <p>Loading your notes...</p>
          </div>
        ) : (
          <motion.div
            key={tab}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
          >
            {tab === 'my-notes' && (
              <div className="notes-table-wrap glass-card">
                {myNotes.length === 0 ? (
                  <div className="empty-state">
                    <div className="empty-icon">📄</div>
                    <h3>No notes uploaded yet</h3>
                    <p>Start sharing your knowledge!</p>
                    <Link to="/upload" className="btn btn-primary" style={{ marginTop: '1rem' }}>
                      <FiUpload /> Upload Note
                    </Link>
                  </div>
                ) : (
                  <table className="notes-table">
                    <thead>
                      <tr>
                        <th>Title</th>
                        <th>Subject</th>
                        <th>Topic</th>
                        <th>Likes</th>
                        <th>Views</th>
                        <th>Status</th>
                        <th>Actions</th>
                      </tr>
                    </thead>
                    <tbody>
                      {myNotes.map(note => (
                        <tr key={note._id}>
                          <td>
                            <span className="note-title-cell">{note.title}</span>
                          </td>
                          <td><span className="badge badge-purple">{note.subject}</span></td>
                          <td><span className="topic-cell">{note.topic}</span></td>
                          <td><span className="likes-cell">❤️ {note.likesCount}</span></td>
                          <td><span className="views-cell">👁️ {note.views}</span></td>
                          <td>
                            <span className={`badge ${note.status === 'approved' ? 'badge-green' : note.status === 'pending' ? 'badge-orange' : 'badge-red'}`}>
                              {note.status}
                            </span>
                          </td>
                          <td>
                            <div className="action-row">
                              <Link to={`/notes/${note._id}`} className="action-icon-btn view" title="View">
                                <FiExternalLink />
                              </Link>
                              <button className="action-icon-btn delete" onClick={() => handleDelete(note._id)} title="Delete">
                                <FiTrash2 />
                              </button>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                )}
              </div>
            )}

            {tab === 'saved' && (
              savedNotes.length === 0 ? (
                <div className="empty-state">
                  <div className="empty-icon">🔖</div>
                  <h3>No saved notes</h3>
                  <p>Browse notes and save the ones you like</p>
                  <Link to="/notes" className="btn btn-primary" style={{ marginTop: '1rem' }}>Browse Notes</Link>
                </div>
              ) : (
                <div className="notes-grid">
                  {savedNotes.map(note => (
                    note && (
                      <div key={note._id} className="saved-note-card glass-card">
                        <div className="saved-note-body">
                          <span className="badge badge-purple" style={{ marginBottom: '0.5rem', display: 'inline-flex' }}>{note.subject}</span>
                          <h3 className="saved-note-title">{note.title}</h3>
                          <p className="note-topic">📌 {note.topic}</p>
                        </div>
                        <div className="saved-note-footer">
                          <span>❤️ {note.likesCount}</span>
                          <Link to={`/notes/${note._id}`} className="btn btn-primary btn-sm">View →</Link>
                        </div>
                      </div>
                    )
                  ))}
                </div>
              )
            )}
          </motion.div>
        )}
      </div>
    </div>
  );
};

export default DashboardPage;
