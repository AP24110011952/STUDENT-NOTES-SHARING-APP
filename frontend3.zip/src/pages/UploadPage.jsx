import { useState, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { FiUpload, FiX, FiFileText, FiCheckCircle } from 'react-icons/fi';
import { notesAPI } from '../services/api';
import toast from 'react-hot-toast';
import './UploadPage.css';

const SUBJECTS = ['Mathematics', 'Computer Science', 'Physics', 'Chemistry', 'Biology', 'History', 'Economics', 'Literature', 'Data Science', 'Engineering'];

const UploadPage = () => {
  const navigate = useNavigate();
  const fileRef = useRef();
  const [file, setFile] = useState(null);
  const [dragging, setDragging] = useState(false);
  const [loading, setLoading] = useState(false);
  const [form, setForm] = useState({ title: '', subject: '', topic: '', description: '', tags: '' });

  const handleFile = (f) => {
    if (!f) return;
    const allowed = ['application/pdf', 'text/plain', 'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'];
    if (!allowed.includes(f.type) && !f.name.match(/\.(pdf|txt|docx|doc)$/i)) {
      return toast.error('Only PDF, TXT, and DOCX files allowed');
    }
    if (f.size > 10 * 1024 * 1024) return toast.error('File size must be under 10MB');
    setFile(f);
  };

  const handleDrop = (e) => {
    e.preventDefault();
    setDragging(false);
    const f = e.dataTransfer.files[0];
    handleFile(f);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!file) return toast.error('Please select a file to upload');
    if (!form.title || !form.subject || !form.topic) return toast.error('Title, subject, and topic are required');
    setLoading(true);
    try {
      const fd = new FormData();
      fd.append('file', file);
      fd.append('title', form.title);
      fd.append('subject', form.subject);
      fd.append('topic', form.topic);
      fd.append('description', form.description);
      if (form.tags) {
        fd.append('tags', JSON.stringify(form.tags.split(',').map(t => t.trim()).filter(Boolean)));
      }
      const { data } = await notesAPI.upload(fd);
      toast.success('Note uploaded successfully! 🎉');
      navigate(`/notes/${data.data._id}`);
    } catch (err) {
      toast.error(err.response?.data?.message || 'Upload failed');
    }
    setLoading(false);
  };

  const formatSize = (bytes) => {
    if (bytes < 1048576) return `${(bytes / 1024).toFixed(0)} KB`;
    return `${(bytes / 1048576).toFixed(1)} MB`;
  };

  return (
    <div className="upload-page page-wrapper">
      <div className="container">
        <motion.div
          className="upload-header"
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
        >
          <h1>Upload Your Notes</h1>
          <p>Share your knowledge with the student community</p>
        </motion.div>

        <div className="upload-layout">
          <motion.form
            className="upload-form glass-card"
            onSubmit={handleSubmit}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
          >
            {/* File Drop Zone */}
            <div
              className={`drop-zone ${dragging ? 'dragging' : ''} ${file ? 'has-file' : ''}`}
              onDragOver={(e) => { e.preventDefault(); setDragging(true); }}
              onDragLeave={() => setDragging(false)}
              onDrop={handleDrop}
              onClick={() => !file && fileRef.current.click()}
            >
              <input
                type="file"
                ref={fileRef}
                style={{ display: 'none' }}
                accept=".pdf,.txt,.docx,.doc"
                onChange={e => handleFile(e.target.files[0])}
                id="file-input"
              />
              {file ? (
                <div className="file-preview">
                  <FiFileText className="file-icon" />
                  <div className="file-info">
                    <strong>{file.name}</strong>
                    <span>{formatSize(file.size)}</span>
                  </div>
                  <button
                    type="button"
                    className="remove-file"
                    onClick={e => { e.stopPropagation(); setFile(null); }}
                  >
                    <FiX />
                  </button>
                </div>
              ) : (
                <div className="drop-content">
                  <div className="drop-icon">
                    <FiUpload />
                  </div>
                  <h3>Drag & Drop your file here</h3>
                  <p>or click to browse</p>
                  <div className="allowed-types">
                    <span>PDF</span><span>TXT</span><span>DOCX</span>
                  </div>
                  <p className="size-limit">Maximum file size: 10MB</p>
                </div>
              )}
            </div>

            <div className="form-row">
              <div className="form-group" style={{ flex: 2 }}>
                <label className="form-label">Note Title *</label>
                <input
                  type="text"
                  className="form-input"
                  placeholder="e.g., Introduction to Data Structures"
                  value={form.title}
                  onChange={e => setForm({ ...form, title: e.target.value })}
                  required
                  maxLength={100}
                  id="upload-title"
                />
              </div>
            </div>

            <div className="form-row">
              <div className="form-group">
                <label className="form-label">Subject *</label>
                <select
                  className="form-select"
                  value={form.subject}
                  onChange={e => setForm({ ...form, subject: e.target.value })}
                  required
                  id="upload-subject"
                >
                  <option value="">Select Subject</option>
                  {SUBJECTS.map(s => <option key={s} value={s}>{s}</option>)}
                </select>
              </div>
              <div className="form-group">
                <label className="form-label">Topic *</label>
                <input
                  type="text"
                  className="form-input"
                  placeholder="e.g., Binary Trees"
                  value={form.topic}
                  onChange={e => setForm({ ...form, topic: e.target.value })}
                  required
                  id="upload-topic"
                />
              </div>
            </div>

            <div className="form-group">
              <label className="form-label">Description</label>
              <textarea
                className="form-textarea"
                placeholder="What's covered in these notes? This helps others find your notes..."
                value={form.description}
                onChange={e => setForm({ ...form, description: e.target.value })}
                rows={3}
                maxLength={500}
                id="upload-description"
              />
              <small className="char-count">{form.description.length}/500</small>
            </div>

            <div className="form-group">
              <label className="form-label">Tags (comma-separated)</label>
              <input
                type="text"
                className="form-input"
                placeholder="e.g., algorithms, trees, CS fundamentals"
                value={form.tags}
                onChange={e => setForm({ ...form, tags: e.target.value })}
                id="upload-tags"
              />
            </div>

            <button
              type="submit"
              className="btn btn-primary"
              style={{ width: '100%', padding: '0.875rem' }}
              disabled={loading}
              id="upload-submit"
            >
              {loading ? (
                <>
                  <span className="spinner" style={{ width: '18px', height: '18px', borderWidth: '2px' }} />
                  Uploading...
                </>
              ) : (
                <>
                  <FiUpload /> Upload Note
                </>
              )}
            </button>
          </motion.form>

          {/* Tips sidebar */}
          <motion.div
            className="upload-tips"
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.2 }}
          >
            <div className="tips-card glass-card">
              <h3>📝 Upload Tips</h3>
              <ul className="tips-list">
                {[
                  'Use clear, descriptive titles so others can find your notes',
                  'Add a detailed description to help students know what\'s covered',
                  'Add relevant tags for better discoverability',
                  'Choose the correct subject and topic for proper categorization',
                  'Ensure your PDF is readable and well-formatted',
                  'Maximum file size is 10MB'
                ].map((tip, i) => (
                  <li key={i}>
                    <FiCheckCircle className="tip-icon" />
                    <span>{tip}</span>
                  </li>
                ))}
              </ul>
            </div>
          </motion.div>
        </div>
      </div>
    </div>
  );
};

export default UploadPage;
