import { useState, useEffect } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import {
  FiHeart, FiBookmark, FiDownload, FiEye, FiMessageCircle,
  FiArrowLeft, FiSend, FiTrash2, FiFileText, FiUser, FiCalendar, FiTag
} from 'react-icons/fi';
import { notesAPI, interactionsAPI } from '../services/api';
import { useAuth } from '../context/AuthContext';
import toast from 'react-hot-toast';
import './NoteDetailPage.css';

const NoteDetailPage = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const { user, isAuthenticated, isAdmin } = useAuth();
  const [note, setNote] = useState(null);
  const [comments, setComments] = useState([]);
  const [loading, setLoading] = useState(true);
  const [commentText, setCommentText] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [liked, setLiked] = useState(false);
  const [saved, setSaved] = useState(false);
  const [likesCount, setLikesCount] = useState(0);
  const [actionLoading, setActionLoading] = useState(false);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const [noteRes, commentsRes] = await Promise.all([
          notesAPI.getById(id),
          interactionsAPI.getComments(id)
        ]);
        setNote(noteRes.data.data);
        setLiked(noteRes.data.data.isLiked || false);
        setSaved(noteRes.data.data.isSaved || false);
        setLikesCount(noteRes.data.data.likesCount || 0);
        setComments(commentsRes.data.data);
      } catch (err) {
        toast.error('Note not found');
        navigate('/notes');
      }
      setLoading(false);
    };
    fetchData();
  }, [id]);

  const handleLike = async () => {
    if (!isAuthenticated) return toast.error('Please login to like');
    setActionLoading(true);
    try {
      if (liked) {
        await interactionsAPI.unlike(id);
        setLiked(false);
        setLikesCount(p => Math.max(0, p - 1));
      } else {
        await interactionsAPI.like(id);
        setLiked(true);
        setLikesCount(p => p + 1);
      }
    } catch { toast.error('Action failed'); }
    setActionLoading(false);
  };

  const handleSave = async () => {
    if (!isAuthenticated) return toast.error('Please login to save');
    setActionLoading(true);
    try {
      if (saved) {
        await interactionsAPI.unsave(id);
        setSaved(false);
        toast.success('Removed from saved');
      } else {
        await interactionsAPI.save(id);
        setSaved(true);
        toast.success('Note saved! ✨');
      }
    } catch { toast.error('Action failed'); }
    setActionLoading(false);
  };

  const handleComment = async (e) => {
    e.preventDefault();
    if (!commentText.trim()) return;
    setSubmitting(true);
    try {
      const { data } = await interactionsAPI.addComment(id, { commentText });
      setComments(prev => [data.data, ...prev]);
      setCommentText('');
      toast.success('Comment added!');
    } catch { toast.error('Failed to add comment'); }
    setSubmitting(false);
  };

  const handleDeleteComment = async (commentId) => {
    try {
      await interactionsAPI.deleteComment(commentId);
      setComments(prev => prev.filter(c => c._id !== commentId));
      toast.success('Comment deleted');
    } catch { toast.error('Failed to delete comment'); }
  };

  const handleDelete = async () => {
    if (!window.confirm('Delete this note? This cannot be undone.')) return;
    try {
      await notesAPI.delete(id);
      toast.success('Note deleted');
      navigate('/dashboard');
    } catch { toast.error('Failed to delete note'); }
  };

  const formatDate = (d) => new Date(d).toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' });

  if (loading) return (
    <div className="page-wrapper loading-container">
      <div className="spinner" />
      <p>Loading note...</p>
    </div>
  );

  if (!note) return null;

  const isOwner = user && note.uploadedBy?._id === user._id;

  return (
    <div className="note-detail-page page-wrapper">
      <div className="container">
        {/* Back button */}
        <button className="back-btn" onClick={() => navigate(-1)}>
          <FiArrowLeft /> Back
        </button>

        <div className="detail-layout">
          {/* Main content */}
          <motion.div
            className="detail-main"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
          >
            {/* Note header */}
            <div className="note-detail-card glass-card">
              <div className="note-detail-header">
                <div className="note-detail-badges">
                  <span className="badge badge-purple">{note.subject}</span>
                  <span className="badge badge-cyan">{note.topic}</span>
                  <span className="badge badge-green">
                    <FiFileText size={10} /> {note.fileType?.toUpperCase()}
                  </span>
                </div>
                {(isOwner || isAdmin) && (
                  <button className="btn btn-danger btn-sm" onClick={handleDelete}>
                    <FiTrash2 /> Delete
                  </button>
                )}
              </div>

              <h1 className="note-detail-title">{note.title}</h1>

              {note.description && (
                <p className="note-detail-desc">{note.description}</p>
              )}

              {/* Tags */}
              {note.tags?.length > 0 && (
                <div className="note-tags-wrap">
                  <FiTag size={14} />
                  {note.tags.map(tag => (
                    <span key={tag} className="note-tag">#{tag}</span>
                  ))}
                </div>
              )}

              {/* Metadata */}
              <div className="note-meta-grid">
                <div className="meta-item">
                  <FiUser size={14} />
                  <span>Uploaded by <strong>{note.uploadedBy?.name}</strong></span>
                </div>
                <div className="meta-item">
                  <FiCalendar size={14} />
                  <span>{formatDate(note.createdAt)}</span>
                </div>
                <div className="meta-item">
                  <FiEye size={14} />
                  <span>{note.views} views</span>
                </div>
                <div className="meta-item">
                  <FiMessageCircle size={14} />
                  <span>{comments.length} comments</span>
                </div>
              </div>

              {/* Action buttons */}
              <div className="note-actions-row">
                <button
                  className={`action-btn-large ${liked ? 'active-like' : ''}`}
                  onClick={handleLike}
                  disabled={actionLoading}
                >
                  <FiHeart fill={liked ? 'currentColor' : 'none'} />
                  {liked ? 'Liked' : 'Like'} · {likesCount}
                </button>
                <button
                  className={`action-btn-large ${saved ? 'active-save' : ''}`}
                  onClick={handleSave}
                  disabled={actionLoading}
                >
                  <FiBookmark fill={saved ? 'currentColor' : 'none'} />
                  {saved ? 'Saved' : 'Save'}
                </button>
                <a
                  href={`http://localhost:5000${note.fileUrl}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="action-btn-large download"
                >
                  <FiDownload /> Download
                </a>
              </div>
            </div>

            {/* Comments section */}
            <div className="comments-section glass-card">
              <h2 className="comments-title">
                <FiMessageCircle /> Comments ({comments.length})
              </h2>

              {isAuthenticated ? (
                <form className="comment-form" onSubmit={handleComment}>
                  <div className="avatar avatar-md">{user?.name?.charAt(0)}</div>
                  <div className="comment-input-wrap">
                    <textarea
                      className="form-textarea"
                      placeholder="Share your thoughts or ask a question..."
                      value={commentText}
                      onChange={e => setCommentText(e.target.value)}
                      rows={2}
                      id="comment-input"
                    />
                    <button
                      type="submit"
                      className="btn btn-primary btn-sm comment-submit"
                      disabled={submitting || !commentText.trim()}
                    >
                      <FiSend /> {submitting ? 'Posting...' : 'Post'}
                    </button>
                  </div>
                </form>
              ) : (
                <div className="login-prompt">
                  <Link to="/login" className="btn btn-primary btn-sm">Login to comment</Link>
                </div>
              )}

              <div className="comments-list">
                {comments.length === 0 ? (
                  <div className="empty-state" style={{ padding: '2rem' }}>
                    <div className="empty-icon" style={{ fontSize: '2rem' }}>💬</div>
                    <p>No comments yet. Be the first!</p>
                  </div>
                ) : (
                  comments.map(comment => (
                    <motion.div
                      key={comment._id}
                      className="comment-item"
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                    >
                      <div className="avatar avatar-sm">{comment.userId?.name?.charAt(0)}</div>
                      <div className="comment-content">
                        <div className="comment-header">
                          <strong>{comment.userId?.name}</strong>
                          {comment.userId?.role === 'admin' && <span className="admin-badge">Admin</span>}
                          <span className="comment-time">
                            {new Date(comment.createdAt).toLocaleDateString()}
                          </span>
                        </div>
                        <p className="comment-text">{comment.commentText}</p>
                      </div>
                      {(user?._id === comment.userId?._id || isAdmin) && (
                        <button
                          className="delete-comment-btn"
                          onClick={() => handleDeleteComment(comment._id)}
                          title="Delete comment"
                        >
                          <FiTrash2 size={13} />
                        </button>
                      )}
                    </motion.div>
                  ))
                )}
              </div>
            </div>
          </motion.div>

          {/* Sidebar */}
          <motion.div
            className="detail-sidebar"
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.2 }}
          >
            {/* Uploader info */}
            <div className="sidebar-card glass-card">
              <h3>About the Uploader</h3>
              <div className="uploader-info">
                <div className="avatar avatar-lg">{note.uploadedBy?.name?.charAt(0)}</div>
                <div>
                  <strong>{note.uploadedBy?.name}</strong>
                  <p>{note.uploadedBy?.bio || 'Passionate student'}</p>
                  <span className={`badge ${note.uploadedBy?.role === 'admin' ? 'badge-purple' : 'badge-cyan'}`}>
                    {note.uploadedBy?.role}
                  </span>
                </div>
              </div>
            </div>

            {/* Note stats */}
            <div className="sidebar-card glass-card">
              <h3>Note Stats</h3>
              <div className="stats-list">
                <div className="stat-row"><span>❤️ Likes</span><strong>{likesCount}</strong></div>
                <div className="stat-row"><span>💬 Comments</span><strong>{comments.length}</strong></div>
                <div className="stat-row"><span>🔖 Saves</span><strong>{note.savesCount}</strong></div>
                <div className="stat-row"><span>👁️ Views</span><strong>{note.views}</strong></div>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </div>
  );
};

export default NoteDetailPage;
