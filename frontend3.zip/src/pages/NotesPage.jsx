import { useState, useEffect, useCallback } from 'react';
import { motion } from 'framer-motion';
import { FiSearch, FiFilter, FiX, FiChevronLeft, FiChevronRight } from 'react-icons/fi';
import { notesAPI, categoriesAPI } from '../services/api';
import NoteCard from '../components/NoteCard';
import './NotesPage.css';

const SUBJECTS = ['Mathematics', 'Computer Science', 'Physics', 'Chemistry', 'Biology', 'History', 'Economics', 'Literature', 'Data Science', 'Engineering'];
const SORT_OPTIONS = [
  { value: 'newest', label: 'Newest First' },
  { value: 'oldest', label: 'Oldest First' },
  { value: 'popular', label: 'Most Liked' },
  { value: 'trending', label: 'Most Viewed' }
];

const NotesPage = () => {
  const [notes, setNotes] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [debouncedSearch, setDebouncedSearch] = useState('');
  const [subject, setSubject] = useState('');
  const [sort, setSort] = useState('newest');
  const [page, setPage] = useState(1);
  const [pagination, setPagination] = useState({ total: 0, pages: 1 });
  const [filterOpen, setFilterOpen] = useState(false);

  // Debounce search
  useEffect(() => {
    const t = setTimeout(() => setDebouncedSearch(search), 400);
    return () => clearTimeout(t);
  }, [search]);

  const fetchNotes = useCallback(async () => {
    setLoading(true);
    try {
      const params = { page, limit: 12, sort };
      if (debouncedSearch) params.search = debouncedSearch;
      if (subject) params.subject = subject;
      const { data } = await notesAPI.getAll(params);
      setNotes(data.data);
      setPagination(data.pagination);
    } catch (err) {
      console.error('Failed to fetch notes:', err);
    }
    setLoading(false);
  }, [page, debouncedSearch, subject, sort]);

  useEffect(() => { fetchNotes(); }, [fetchNotes]);
  useEffect(() => { setPage(1); }, [debouncedSearch, subject, sort]);

  const clearFilters = () => { setSearch(''); setSubject(''); setSort('newest'); setPage(1); };
  const hasFilters = search || subject || sort !== 'newest';

  return (
    <div className="notes-page page-wrapper">
      <div className="container">
        {/* Page Header */}
        <motion.div
          className="notes-page-header"
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
        >
          <div>
            <h1>Browse Notes</h1>
            <p className="page-subtitle">
              {pagination.total > 0 ? `${pagination.total} notes available` : 'No notes found'}
            </p>
          </div>
        </motion.div>

        {/* Search + Filters Bar */}
        <motion.div
          className="search-bar-wrap glass-card"
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
        >
          <div className="search-input-wrap">
            <FiSearch className="search-icon" />
            <input
              type="text"
              className="search-input"
              placeholder="Search notes by title, subject, topic..."
              value={search}
              onChange={e => setSearch(e.target.value)}
              id="notes-search"
            />
            {search && (
              <button className="search-clear" onClick={() => setSearch('')}><FiX /></button>
            )}
          </div>

          <div className="filter-controls">
            <select
              className="form-select filter-select"
              value={subject}
              onChange={e => setSubject(e.target.value)}
              id="notes-subject-filter"
            >
              <option value="">All Subjects</option>
              {SUBJECTS.map(s => <option key={s} value={s}>{s}</option>)}
            </select>

            <select
              className="form-select filter-select"
              value={sort}
              onChange={e => setSort(e.target.value)}
              id="notes-sort"
            >
              {SORT_OPTIONS.map(o => <option key={o.value} value={o.value}>{o.label}</option>)}
            </select>

            {hasFilters && (
              <button className="btn btn-secondary btn-sm" onClick={clearFilters}>
                <FiX /> Clear
              </button>
            )}
          </div>
        </motion.div>

        {/* Subject Quick Filters */}
        <div className="subject-chips">
          <button
            className={`subject-chip ${!subject ? 'active' : ''}`}
            onClick={() => setSubject('')}
          >
            All
          </button>
          {SUBJECTS.map(s => (
            <button
              key={s}
              className={`subject-chip ${subject === s ? 'active' : ''}`}
              onClick={() => setSubject(subject === s ? '' : s)}
            >
              {s}
            </button>
          ))}
        </div>

        {/* Notes Grid */}
        {loading ? (
          <div className="loading-container">
            <div className="spinner" />
            <p>Loading notes...</p>
          </div>
        ) : notes.length === 0 ? (
          <div className="empty-state">
            <div className="empty-icon">📭</div>
            <h3>No notes found</h3>
            <p>Try adjusting your search or filters</p>
            {hasFilters && (
              <button className="btn btn-primary" style={{ marginTop: '1rem' }} onClick={clearFilters}>
                Clear Filters
              </button>
            )}
          </div>
        ) : (
          <motion.div
            className="notes-grid stagger-children"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.2 }}
          >
            {notes.map(note => (
              <motion.div
                key={note._id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
              >
                <NoteCard note={note} />
              </motion.div>
            ))}
          </motion.div>
        )}

        {/* Pagination */}
        {pagination.pages > 1 && (
          <div className="pagination">
            <button
              className="page-btn"
              onClick={() => setPage(p => p - 1)}
              disabled={page === 1}
            >
              <FiChevronLeft />
            </button>
            {Array.from({ length: Math.min(pagination.pages, 7) }, (_, i) => {
              const p = i + 1;
              return (
                <button
                  key={p}
                  className={`page-btn ${p === page ? 'active' : ''}`}
                  onClick={() => setPage(p)}
                >
                  {p}
                </button>
              );
            })}
            <button
              className="page-btn"
              onClick={() => setPage(p => p + 1)}
              disabled={page === pagination.pages}
            >
              <FiChevronRight />
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

export default NotesPage;
