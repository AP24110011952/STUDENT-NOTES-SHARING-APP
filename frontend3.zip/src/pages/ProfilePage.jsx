import { useState } from 'react';
import { motion } from 'framer-motion';
import { FiUser, FiMail, FiSave, FiLock } from 'react-icons/fi';
import { useAuth } from '../context/AuthContext';
import { authAPI } from '../services/api';
import toast from 'react-hot-toast';
import './ProfilePage.css';

const ProfilePage = () => {
  const { user, updateUser } = useAuth();
  const [profile, setProfile] = useState({ name: user?.name || '', bio: user?.bio || '' });
  const [passwords, setPasswords] = useState({ currentPassword: '', newPassword: '', confirm: '' });
  const [loading, setLoading] = useState(false);
  const [passLoading, setPassLoading] = useState(false);

  const handleProfileSave = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      const { data } = await authAPI.updateProfile(profile);
      updateUser(data.user);
      toast.success('Profile updated! ✨');
    } catch (err) {
      toast.error(err.response?.data?.message || 'Update failed');
    }
    setLoading(false);
  };

  const handlePasswordChange = async (e) => {
    e.preventDefault();
    if (passwords.newPassword !== passwords.confirm) return toast.error('Passwords do not match');
    if (passwords.newPassword.length < 6) return toast.error('Password must be at least 6 characters');
    setPassLoading(true);
    try {
      await authAPI.changePassword({ currentPassword: passwords.currentPassword, newPassword: passwords.newPassword });
      toast.success('Password updated!');
      setPasswords({ currentPassword: '', newPassword: '', confirm: '' });
    } catch (err) {
      toast.error(err.response?.data?.message || 'Failed to update password');
    }
    setPassLoading(false);
  };

  return (
    <div className="profile-page page-wrapper">
      <div className="container">
        <motion.h1 className="profile-title" initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }}>
          My Profile
        </motion.h1>

        <div className="profile-layout">
          {/* Profile card */}
          <motion.div
            className="profile-card glass-card"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
          >
            <div className="profile-avatar-wrap">
              <div className="avatar avatar-xl profile-avatar">{user?.name?.charAt(0)}</div>
              <div>
                <h2>{user?.name}</h2>
                <p>{user?.email}</p>
                <span className={`badge ${user?.role === 'admin' ? 'badge-purple' : 'badge-cyan'}`}>
                  {user?.role}
                </span>
              </div>
            </div>

            <form onSubmit={handleProfileSave}>
              <div className="form-group">
                <label className="form-label">
                  <FiUser /> Full Name
                </label>
                <input
                  type="text"
                  className="form-input"
                  value={profile.name}
                  onChange={e => setProfile({ ...profile, name: e.target.value })}
                  id="profile-name"
                />
              </div>
              <div className="form-group">
                <label className="form-label">
                  <FiMail /> Email Address
                </label>
                <input
                  type="email"
                  className="form-input"
                  value={user?.email}
                  disabled
                  style={{ opacity: 0.5 }}
                />
              </div>
              <div className="form-group">
                <label className="form-label">Bio</label>
                <textarea
                  className="form-textarea"
                  placeholder="Tell others about yourself..."
                  value={profile.bio}
                  onChange={e => setProfile({ ...profile, bio: e.target.value })}
                  rows={3}
                  maxLength={200}
                  id="profile-bio"
                />
                <small style={{ color: 'var(--text-muted)', fontSize: '0.75rem' }}>{profile.bio.length}/200</small>
              </div>
              <button type="submit" className="btn btn-primary" disabled={loading} id="profile-save">
                {loading ? 'Saving...' : <><FiSave /> Save Changes</>}
              </button>
            </form>
          </motion.div>

          {/* Change password */}
          <motion.div
            className="password-card glass-card"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
          >
            <h2><FiLock /> Change Password</h2>
            <form onSubmit={handlePasswordChange}>
              <div className="form-group">
                <label className="form-label">Current Password</label>
                <input
                  type="password"
                  className="form-input"
                  placeholder="Enter current password"
                  value={passwords.currentPassword}
                  onChange={e => setPasswords({ ...passwords, currentPassword: e.target.value })}
                  required
                  id="current-password"
                />
              </div>
              <div className="form-group">
                <label className="form-label">New Password</label>
                <input
                  type="password"
                  className="form-input"
                  placeholder="Min. 6 characters"
                  value={passwords.newPassword}
                  onChange={e => setPasswords({ ...passwords, newPassword: e.target.value })}
                  required
                  id="new-password"
                />
              </div>
              <div className="form-group">
                <label className="form-label">Confirm New Password</label>
                <input
                  type="password"
                  className="form-input"
                  placeholder="Repeat new password"
                  value={passwords.confirm}
                  onChange={e => setPasswords({ ...passwords, confirm: e.target.value })}
                  required
                  id="confirm-password"
                />
              </div>
              <button type="submit" className="btn btn-primary" disabled={passLoading} id="change-password-submit">
                {passLoading ? 'Updating...' : <><FiLock /> Update Password</>}
              </button>
            </form>
          </motion.div>
        </div>
      </div>
    </div>
  );
};

export default ProfilePage;
