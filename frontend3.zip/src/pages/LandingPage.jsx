import { useEffect, useRef } from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { FiUpload, FiSearch, FiHeart, FiBookmark, FiArrowRight, FiStar } from 'react-icons/fi';
import { useAuth } from '../context/AuthContext';
import './LandingPage.css';

const features = [
  { icon: '📤', title: 'Upload & Share', desc: 'Share your notes in PDF or text format, organized by subject and topic.' },
  { icon: '🔍', title: 'Search & Discover', desc: 'Instantly find notes with powerful search and filter by subject or topic.' },
  { icon: '❤️', title: 'Like & Save', desc: 'Bookmark notes you love and build your personal study collection.' },
  { icon: '💬', title: 'Discuss & Comment', desc: 'Ask questions, share insights, and collaborate with fellow students.' },
  { icon: '📊', title: 'Track Progress', desc: 'Monitor your uploads, saved notes, and engagement from your dashboard.' },
  { icon: '🛡️', title: 'Quality Moderated', desc: 'Admin review ensures every note meets quality standards for learning.' }
];

const stats = [
  { value: '10,000+', label: 'Notes Shared' },
  { value: '5,000+', label: 'Active Students' },
  { value: '50+', label: 'Subjects Covered' },
  { value: '98%', label: 'Satisfaction Rate' }
];

const LandingPage = () => {
  const { isAuthenticated } = useAuth();

  const fadeUp = {
    initial: { opacity: 0, y: 30 },
    animate: { opacity: 1, y: 0 },
    transition: { duration: 0.6 }
  };

  return (
    <div className="landing">
      {/* Hero Section */}
      <section className="hero">
        <div className="hero-bg">
          <div className="hero-orb orb-1" />
          <div className="hero-orb orb-2" />
          <div className="hero-orb orb-3" />
        </div>
        <div className="container hero-content">
          <motion.div className="hero-badge" {...fadeUp} transition={{ duration: 0.5 }}>
            <FiStar className="badge-icon" />
            <span>The #1 Student Notes Platform</span>
          </motion.div>
          <motion.h1 className="hero-title" initial={{ opacity: 0, y: 40 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.7, delay: 0.1 }}>
            Share Knowledge,<br />
            <span className="gradient-text">Ace Your Exams</span>
          </motion.h1>
          <motion.p className="hero-subtitle" initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6, delay: 0.25 }}>
            A centralized platform where students upload, discover, and discuss quality study notes. 
            Stop searching WhatsApp groups — find everything here.
          </motion.p>
          <motion.div className="hero-cta" initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5, delay: 0.4 }}>
            {isAuthenticated ? (
              <>
                <Link to="/notes" className="btn btn-primary btn-lg">
                  <FiSearch /> Browse Notes
                </Link>
                <Link to="/upload" className="btn btn-secondary btn-lg">
                  <FiUpload /> Upload Notes
                </Link>
              </>
            ) : (
              <>
                <Link to="/register" className="btn btn-primary btn-lg">
                  Get Started Free <FiArrowRight />
                </Link>
                <Link to="/notes" className="btn btn-secondary btn-lg">
                  <FiSearch /> Browse Notes
                </Link>
              </>
            )}
          </motion.div>

          {/* Floating note cards preview */}
          <motion.div
            className="hero-preview"
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.8, delay: 0.5 }}
          >
            <div className="preview-card pc-1 glass-card">
              <div className="pc-accent" style={{ background: '#7c3aed' }} />
              <div className="pc-content">
                <span className="pc-badge" style={{ color: '#7c3aed' }}>Computer Science</span>
                <p className="pc-title">Data Structures & Algorithms</p>
                <div className="pc-meta"><span>❤️ 45</span><span>💬 12</span></div>
              </div>
            </div>
            <div className="preview-card pc-2 glass-card">
              <div className="pc-accent" style={{ background: '#06b6d4' }} />
              <div className="pc-content">
                <span className="pc-badge" style={{ color: '#06b6d4' }}>Mathematics</span>
                <p className="pc-title">Calculus Integration Guide</p>
                <div className="pc-meta"><span>❤️ 62</span><span>💬 18</span></div>
              </div>
            </div>
            <div className="preview-card pc-3 glass-card">
              <div className="pc-accent" style={{ background: '#10b981' }} />
              <div className="pc-content">
                <span className="pc-badge" style={{ color: '#10b981' }}>Data Science</span>
                <p className="pc-title">Machine Learning Fundamentals</p>
                <div className="pc-meta"><span>❤️ 89</span><span>💬 31</span></div>
              </div>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Stats */}
      <section className="stats-section">
        <div className="container">
          <div className="stats-grid">
            {stats.map((stat, i) => (
              <motion.div
                key={stat.label}
                className="stat-card glass-card"
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
              >
                <div className="stat-value">{stat.value}</div>
                <div className="stat-label">{stat.label}</div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="features-section">
        <div className="container">
          <motion.div
            className="section-header"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
          >
            <h2>Everything You Need to Study Better</h2>
            <p>Powerful features designed by students, for students</p>
          </motion.div>
          <div className="features-grid">
            {features.map((feature, i) => (
              <motion.div
                key={feature.title}
                className="feature-card glass-card"
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
                whileHover={{ y: -6 }}
              >
                <div className="feature-icon">{feature.icon}</div>
                <h3>{feature.title}</h3>
                <p>{feature.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* How it works */}
      <section className="how-section">
        <div className="container">
          <motion.div className="section-header" initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }}>
            <h2>How It Works</h2>
            <p>Three simple steps to start learning smarter</p>
          </motion.div>
          <div className="steps-grid">
            {[
              { step: '01', title: 'Create Account', desc: 'Sign up for free in seconds. No credit card required.', icon: '👤' },
              { step: '02', title: 'Browse or Upload', desc: 'Search for notes by subject, or share your own study materials.', icon: '📚' },
              { step: '03', title: 'Learn & Interact', desc: 'Like, save, and comment on notes to collaborate with others.', icon: '🚀' }
            ].map((step, i) => (
              <motion.div
                key={step.step}
                className="step-card"
                initial={{ opacity: 0, x: i % 2 === 0 ? -20 : 20 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.15 }}
              >
                <div className="step-number">{step.step}</div>
                <div className="step-icon">{step.icon}</div>
                <h3>{step.title}</h3>
                <p>{step.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Banner */}
      <section className="cta-section">
        <div className="container">
          <motion.div
            className="cta-banner glass-card"
            initial={{ opacity: 0, scale: 0.95 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
          >
            <div className="cta-content">
              <h2>Ready to Transform Your Study Game?</h2>
              <p>Join thousands of students already sharing and discovering quality notes.</p>
              <div className="cta-buttons">
                {!isAuthenticated ? (
                  <Link to="/register" className="btn btn-primary btn-lg">
                    Start for Free <FiArrowRight />
                  </Link>
                ) : (
                  <Link to="/notes" className="btn btn-primary btn-lg">
                    <FiSearch /> Explore Notes
                  </Link>
                )}
              </div>
            </div>
            <div className="cta-decoration">🎓</div>
          </motion.div>
        </div>
      </section>

      {/* Footer */}
      <footer className="footer">
        <div className="container footer-inner">
          <div className="footer-logo">
            <span>📚</span>
            <span className="logo-text">NoteShare<span className="logo-accent">Pro</span></span>
          </div>
          <p className="footer-copy">© 2024 NoteSharePro. Built for students, by students.</p>
        </div>
      </footer>
    </div>
  );
};

export default LandingPage;
