import axios from 'axios';

const API = axios.create({
  baseURL: 'http://localhost:5000/api',
  headers: { 'Content-Type': 'application/json' }
});

// Attach JWT token to every request
API.interceptors.request.use((config) => {
  const token = localStorage.getItem('token');
  if (token) config.headers.Authorization = `Bearer ${token}`;
  return config;
});

// Handle 401 globally
API.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.status === 401) {
      localStorage.removeItem('token');
      localStorage.removeItem('user');
    }
    return Promise.reject(error);
  }
);

// Auth
export const authAPI = {
  register: (data) => API.post('/auth/register', data),
  login: (data) => API.post('/auth/login', data),
  getMe: () => API.get('/auth/me'),
  updateProfile: (data) => API.put('/auth/profile', data),
  changePassword: (data) => API.put('/auth/password', data),
};

// Notes
export const notesAPI = {
  getAll: (params) => API.get('/notes', { params }),
  getById: (id) => API.get(`/notes/${id}`),
  getTrending: () => API.get('/notes/trending'),
  getMyNotes: () => API.get('/notes/my-notes'),
  getSaved: () => API.get('/notes/saved'),
  upload: (formData) => API.post('/notes', formData, { headers: { 'Content-Type': 'multipart/form-data' } }),
  update: (id, data) => API.put(`/notes/${id}`, data),
  delete: (id) => API.delete(`/notes/${id}`),
};

// Interactions
export const interactionsAPI = {
  like: (id) => API.post(`/notes/${id}/like`),
  unlike: (id) => API.delete(`/notes/${id}/like`),
  save: (id) => API.post(`/notes/${id}/save`),
  unsave: (id) => API.delete(`/notes/${id}/save`),
  getComments: (id) => API.get(`/notes/${id}/comments`),
  addComment: (id, data) => API.post(`/notes/${id}/comments`, data),
  deleteComment: (id) => API.delete(`/comments/${id}`),
};

// Categories
export const categoriesAPI = {
  getAll: () => API.get('/categories'),
  create: (data) => API.post('/categories', data),
};

// Admin
export const adminAPI = {
  getStats: () => API.get('/admin/stats'),
  getUsers: () => API.get('/admin/users'),
  updateRole: (id, role) => API.put(`/admin/users/${id}/role`, { role }),
  deleteUser: (id) => API.delete(`/admin/users/${id}`),
  getNotes: (params) => API.get('/admin/notes', { params }),
  approveNote: (id) => API.put(`/admin/notes/${id}/approve`),
  deleteNote: (id) => API.delete(`/admin/notes/${id}`),
};

export default API;
