const Note = require('../models/Note');
const Like = require('../models/Like');
const SavedNote = require('../models/SavedNote');
const User = require('../models/User');
const path = require('path');
const fs = require('fs');

// @desc    Get all approved notes with search & filter
// @route   GET /api/notes
// @access  Public
const getAllNotes = async (req, res) => {
  try {
    const { search, subject, topic, page = 1, limit = 12, sort = 'newest' } = req.query;
    const query = { status: 'approved' };

    if (search) {
      query.$or = [
        { title: { $regex: search, $options: 'i' } },
        { subject: { $regex: search, $options: 'i' } },
        { topic: { $regex: search, $options: 'i' } },
        { description: { $regex: search, $options: 'i' } }
      ];
    }
    if (subject) query.subject = { $regex: subject, $options: 'i' };
    if (topic) query.topic = { $regex: topic, $options: 'i' };

    const sortMap = {
      newest: { createdAt: -1 },
      oldest: { createdAt: 1 },
      popular: { likesCount: -1 },
      trending: { views: -1 }
    };
    const sortOption = sortMap[sort] || sortMap.newest;

    const skip = (parseInt(page) - 1) * parseInt(limit);
    const total = await Note.countDocuments(query);
    const notes = await Note.find(query)
      .populate('uploadedBy', 'name avatar role')
      .sort(sortOption)
      .skip(skip)
      .limit(parseInt(limit));

    // If user is logged in, attach isLiked and isSaved
    let likedIds = [];
    let savedIds = [];
    if (req.user) {
      const likes = await Like.find({ userId: req.user._id, noteId: { $in: notes.map(n => n._id) } });
      const saves = await SavedNote.find({ userId: req.user._id, noteId: { $in: notes.map(n => n._id) } });
      likedIds = likes.map(l => l.noteId.toString());
      savedIds = saves.map(s => s.noteId.toString());
    }

    const enrichedNotes = notes.map(n => ({
      ...n.toObject(),
      isLiked: likedIds.includes(n._id.toString()),
      isSaved: savedIds.includes(n._id.toString())
    }));

    res.json({
      success: true,
      data: enrichedNotes,
      pagination: { total, page: parseInt(page), limit: parseInt(limit), pages: Math.ceil(total / parseInt(limit)) }
    });
  } catch (err) {
    console.error('Get notes error:', err);
    res.status(500).json({ success: false, message: 'Server error' });
  }
};

// @desc    Get single note by ID
// @route   GET /api/notes/:id
// @access  Public
const getNoteById = async (req, res) => {
  try {
    const note = await Note.findById(req.params.id).populate('uploadedBy', 'name avatar role bio');
    if (!note) return res.status(404).json({ success: false, message: 'Note not found' });

    // Increment views
    await Note.findByIdAndUpdate(req.params.id, { $inc: { views: 1 } });

    let isLiked = false;
    let isSaved = false;
    if (req.user) {
      const like = await Like.findOne({ noteId: note._id, userId: req.user._id });
      const save = await SavedNote.findOne({ noteId: note._id, userId: req.user._id });
      isLiked = !!like;
      isSaved = !!save;
    }

    res.json({ success: true, data: { ...note.toObject(), isLiked, isSaved } });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Server error' });
  }
};

// @desc    Upload a new note
// @route   POST /api/notes
// @access  Private
const uploadNote = async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ success: false, message: 'Please upload a file' });
    }
    const { title, description, subject, topic, tags } = req.body;
    if (!title || !subject || !topic) {
      fs.unlinkSync(req.file.path);
      return res.status(400).json({ success: false, message: 'Title, subject, and topic are required' });
    }

    const ext = path.extname(req.file.originalname).toLowerCase().replace('.', '');
    const fileType = ['pdf', 'txt', 'docx', 'doc'].includes(ext) ? (ext === 'doc' ? 'docx' : ext) : 'other';

    const note = await Note.create({
      title,
      description: description || '',
      subject,
      topic,
      tags: tags ? JSON.parse(tags) : [],
      fileUrl: `/uploads/${req.file.filename}`,
      fileName: req.file.originalname,
      fileType,
      fileSize: req.file.size,
      uploadedBy: req.user._id,
      status: 'approved'
    });

    await User.findByIdAndUpdate(req.user._id, { $inc: { uploadedNotes: 1 } });

    const populated = await Note.findById(note._id).populate('uploadedBy', 'name avatar role');
    res.status(201).json({ success: true, message: 'Note uploaded successfully', data: populated });
  } catch (err) {
    console.error('Upload error:', err);
    if (req.file && fs.existsSync(req.file.path)) fs.unlinkSync(req.file.path);
    res.status(500).json({ success: false, message: 'Server error during upload' });
  }
};

// @desc    Update a note
// @route   PUT /api/notes/:id
// @access  Private (owner or admin)
const updateNote = async (req, res) => {
  try {
    const note = await Note.findById(req.params.id);
    if (!note) return res.status(404).json({ success: false, message: 'Note not found' });
    if (note.uploadedBy.toString() !== req.user._id.toString() && req.user.role !== 'admin') {
      return res.status(403).json({ success: false, message: 'Not authorized to update this note' });
    }
    const { title, description, subject, topic, tags } = req.body;
    const updatedNote = await Note.findByIdAndUpdate(
      req.params.id,
      { title, description, subject, topic, tags: tags ? JSON.parse(tags) : note.tags },
      { new: true, runValidators: true }
    ).populate('uploadedBy', 'name avatar role');
    res.json({ success: true, message: 'Note updated', data: updatedNote });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Server error' });
  }
};

// @desc    Delete a note
// @route   DELETE /api/notes/:id
// @access  Private (owner or admin)
const deleteNote = async (req, res) => {
  try {
    const note = await Note.findById(req.params.id);
    if (!note) return res.status(404).json({ success: false, message: 'Note not found' });
    if (note.uploadedBy.toString() !== req.user._id.toString() && req.user.role !== 'admin') {
      return res.status(403).json({ success: false, message: 'Not authorized to delete this note' });
    }
    // Delete file from server
    const filePath = path.join(__dirname, '../', note.fileUrl);
    if (fs.existsSync(filePath)) fs.unlinkSync(filePath);

    await Note.findByIdAndDelete(req.params.id);
    await User.findByIdAndUpdate(note.uploadedBy, { $inc: { uploadedNotes: -1 } });
    res.json({ success: true, message: 'Note deleted successfully' });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Server error' });
  }
};

// @desc    Get my uploaded notes
// @route   GET /api/notes/my-notes
// @access  Private
const getMyNotes = async (req, res) => {
  try {
    const notes = await Note.find({ uploadedBy: req.user._id })
      .populate('uploadedBy', 'name avatar role')
      .sort({ createdAt: -1 });
    res.json({ success: true, data: notes });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Server error' });
  }
};

// @desc    Get trending notes
// @route   GET /api/notes/trending
// @access  Public
const getTrendingNotes = async (req, res) => {
  try {
    const notes = await Note.find({ status: 'approved' })
      .populate('uploadedBy', 'name avatar')
      .sort({ likesCount: -1, views: -1 })
      .limit(6);
    res.json({ success: true, data: notes });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Server error' });
  }
};

module.exports = { getAllNotes, getNoteById, uploadNote, updateNote, deleteNote, getMyNotes, getTrendingNotes };
