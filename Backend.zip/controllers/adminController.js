const User = require('../models/User');
const Note = require('../models/Note');
const Comment = require('../models/Comment');
const Like = require('../models/Like');
const SavedNote = require('../models/SavedNote');
const path = require('path');
const fs = require('fs');

// @desc    Get dashboard stats
// @route   GET /api/admin/stats
// @access  Admin
const getDashboardStats = async (req, res) => {
  try {
    const [totalUsers, totalNotes, totalComments, totalLikes, pendingNotes, recentUsers, recentNotes] = await Promise.all([
      User.countDocuments({ role: 'student' }),
      Note.countDocuments({ status: 'approved' }),
      Comment.countDocuments(),
      Like.countDocuments(),
      Note.countDocuments({ status: 'pending' }),
      User.find({ role: 'student' }).sort({ createdAt: -1 }).limit(5).select('name email createdAt'),
      Note.find().sort({ createdAt: -1 }).limit(5).populate('uploadedBy', 'name').select('title subject status createdAt uploadedBy')
    ]);
    res.json({
      success: true,
      data: { totalUsers, totalNotes, totalComments, totalLikes, pendingNotes, recentUsers, recentNotes }
    });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Server error' });
  }
};

// @desc    Get all users
// @route   GET /api/admin/users
// @access  Admin
const getAllUsers = async (req, res) => {
  try {
    const users = await User.find().sort({ createdAt: -1 });
    res.json({ success: true, data: users });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Server error' });
  }
};

// @desc    Update user role
// @route   PUT /api/admin/users/:id/role
// @access  Admin
const updateUserRole = async (req, res) => {
  try {
    const { role } = req.body;
    if (!['student', 'admin'].includes(role)) {
      return res.status(400).json({ success: false, message: 'Invalid role' });
    }
    const user = await User.findByIdAndUpdate(req.params.id, { role }, { new: true });
    if (!user) return res.status(404).json({ success: false, message: 'User not found' });
    res.json({ success: true, message: 'User role updated', data: user });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Server error' });
  }
};

// @desc    Delete a user
// @route   DELETE /api/admin/users/:id
// @access  Admin
const deleteUser = async (req, res) => {
  try {
    const user = await User.findByIdAndDelete(req.params.id);
    if (!user) return res.status(404).json({ success: false, message: 'User not found' });
    res.json({ success: true, message: 'User deleted' });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Server error' });
  }
};

// @desc    Get all notes (admin view)
// @route   GET /api/admin/notes
// @access  Admin
const getAllNotesAdmin = async (req, res) => {
  try {
    const { status, page = 1, limit = 20 } = req.query;
    const query = {};
    if (status) query.status = status;
    const skip = (parseInt(page) - 1) * parseInt(limit);
    const total = await Note.countDocuments(query);
    const notes = await Note.find(query)
      .populate('uploadedBy', 'name email')
      .sort({ createdAt: -1 })
      .skip(skip)
      .limit(parseInt(limit));
    res.json({ success: true, data: notes, pagination: { total, page: parseInt(page), pages: Math.ceil(total / parseInt(limit)) } });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Server error' });
  }
};

// @desc    Approve a note
// @route   PUT /api/admin/notes/:id/approve
// @access  Admin
const approveNote = async (req, res) => {
  try {
    const note = await Note.findByIdAndUpdate(req.params.id, { status: 'approved' }, { new: true });
    if (!note) return res.status(404).json({ success: false, message: 'Note not found' });
    res.json({ success: true, message: 'Note approved', data: note });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Server error' });
  }
};

// @desc    Reject / delete a note (admin)
// @route   DELETE /api/admin/notes/:id
// @access  Admin
const deleteNoteAdmin = async (req, res) => {
  try {
    const note = await Note.findById(req.params.id);
    if (!note) return res.status(404).json({ success: false, message: 'Note not found' });
    const filePath = path.join(__dirname, '../', note.fileUrl);
    if (fs.existsSync(filePath)) fs.unlinkSync(filePath);
    await Note.findByIdAndDelete(req.params.id);
    res.json({ success: true, message: 'Note deleted by admin' });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Server error' });
  }
};

module.exports = { getDashboardStats, getAllUsers, updateUserRole, deleteUser, getAllNotesAdmin, approveNote, deleteNoteAdmin };
