const Like = require('../models/Like');
const SavedNote = require('../models/SavedNote');
const Comment = require('../models/Comment');
const Note = require('../models/Note');

// @desc    Like a note
// @route   POST /api/notes/:id/like
// @access  Private
const likeNote = async (req, res) => {
  try {
    const noteId = req.params.id;
    const userId = req.user._id;
    const existing = await Like.findOne({ noteId, userId });
    if (existing) {
      return res.status(400).json({ success: false, message: 'Already liked this note' });
    }
    await Like.create({ noteId, userId });
    const note = await Note.findByIdAndUpdate(noteId, { $inc: { likesCount: 1 } }, { new: true });
    res.json({ success: true, message: 'Note liked', likesCount: note.likesCount });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Server error' });
  }
};

// @desc    Unlike a note
// @route   DELETE /api/notes/:id/like
// @access  Private
const unlikeNote = async (req, res) => {
  try {
    const noteId = req.params.id;
    const userId = req.user._id;
    const existing = await Like.findOneAndDelete({ noteId, userId });
    if (!existing) {
      return res.status(400).json({ success: false, message: 'Not liked yet' });
    }
    const note = await Note.findByIdAndUpdate(noteId, { $inc: { likesCount: -1 } }, { new: true });
    res.json({ success: true, message: 'Note unliked', likesCount: Math.max(0, note.likesCount) });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Server error' });
  }
};

// @desc    Save a note
// @route   POST /api/notes/:id/save
// @access  Private
const saveNote = async (req, res) => {
  try {
    const noteId = req.params.id;
    const userId = req.user._id;
    const existing = await SavedNote.findOne({ noteId, userId });
    if (existing) {
      return res.status(400).json({ success: false, message: 'Note already saved' });
    }
    await SavedNote.create({ noteId, userId });
    const note = await Note.findByIdAndUpdate(noteId, { $inc: { savesCount: 1 } }, { new: true });
    res.json({ success: true, message: 'Note saved', savesCount: note.savesCount });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Server error' });
  }
};

// @desc    Unsave a note
// @route   DELETE /api/notes/:id/save
// @access  Private
const unsaveNote = async (req, res) => {
  try {
    const noteId = req.params.id;
    const userId = req.user._id;
    const existing = await SavedNote.findOneAndDelete({ noteId, userId });
    if (!existing) {
      return res.status(400).json({ success: false, message: 'Note not saved' });
    }
    const note = await Note.findByIdAndUpdate(noteId, { $inc: { savesCount: -1 } }, { new: true });
    res.json({ success: true, message: 'Note removed from saved', savesCount: Math.max(0, note.savesCount) });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Server error' });
  }
};

// @desc    Get saved notes
// @route   GET /api/notes/saved
// @access  Private
const getSavedNotes = async (req, res) => {
  try {
    const savedNotes = await SavedNote.find({ userId: req.user._id })
      .populate({
        path: 'noteId',
        populate: { path: 'uploadedBy', select: 'name avatar role' }
      })
      .sort({ createdAt: -1 });
    const notes = savedNotes.map(sn => sn.noteId).filter(Boolean);
    res.json({ success: true, data: notes });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Server error' });
  }
};

// @desc    Get comments for a note
// @route   GET /api/notes/:id/comments
// @access  Public
const getComments = async (req, res) => {
  try {
    const comments = await Comment.find({ noteId: req.params.id })
      .populate('userId', 'name avatar role')
      .sort({ createdAt: -1 });
    res.json({ success: true, data: comments });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Server error' });
  }
};

// @desc    Add comment to a note
// @route   POST /api/notes/:id/comments
// @access  Private
const addComment = async (req, res) => {
  try {
    const { commentText } = req.body;
    if (!commentText || !commentText.trim()) {
      return res.status(400).json({ success: false, message: 'Comment text is required' });
    }
    const comment = await Comment.create({
      noteId: req.params.id,
      userId: req.user._id,
      commentText: commentText.trim()
    });
    await Note.findByIdAndUpdate(req.params.id, { $inc: { commentsCount: 1 } });
    const populated = await Comment.findById(comment._id).populate('userId', 'name avatar role');
    res.status(201).json({ success: true, message: 'Comment added', data: populated });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Server error' });
  }
};

// @desc    Delete a comment
// @route   DELETE /api/comments/:id
// @access  Private (owner or admin)
const deleteComment = async (req, res) => {
  try {
    const comment = await Comment.findById(req.params.id);
    if (!comment) return res.status(404).json({ success: false, message: 'Comment not found' });
    if (comment.userId.toString() !== req.user._id.toString() && req.user.role !== 'admin') {
      return res.status(403).json({ success: false, message: 'Not authorized' });
    }
    await Comment.findByIdAndDelete(req.params.id);
    await Note.findByIdAndUpdate(comment.noteId, { $inc: { commentsCount: -1 } });
    res.json({ success: true, message: 'Comment deleted' });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Server error' });
  }
};

module.exports = { likeNote, unlikeNote, saveNote, unsaveNote, getSavedNotes, getComments, addComment, deleteComment };
