require('dotenv').config();
const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');
const User = require('./models/User');
const Category = require('./models/Category');
const Note = require('./models/Note');

const categories = [
  { name: 'Mathematics', description: 'Algebra, Calculus, Statistics, and more', icon: '📐', color: '#7c3aed' },
  { name: 'Computer Science', description: 'Programming, Data Structures, Algorithms', icon: '💻', color: '#06b6d4' },
  { name: 'Physics', description: 'Mechanics, Thermodynamics, Electromagnetism', icon: '⚛️', color: '#f59e0b' },
  { name: 'Chemistry', description: 'Organic, Inorganic, Physical Chemistry', icon: '🧪', color: '#10b981' },
  { name: 'Biology', description: 'Cell Biology, Genetics, Ecology', icon: '🧬', color: '#ef4444' },
  { name: 'History', description: 'World History, Ancient Civilizations, Modern Era', icon: '🏛️', color: '#8b5cf6' },
  { name: 'Economics', description: 'Micro, Macro Economics, Finance', icon: '📈', color: '#f97316' },
  { name: 'Literature', description: 'English Literature, Poetry, Fiction Analysis', icon: '📖', color: '#ec4899' },
  { name: 'Data Science', description: 'Machine Learning, Statistics, Data Analysis', icon: '📊', color: '#14b8a6' },
  { name: 'Engineering', description: 'Electrical, Mechanical, Civil Engineering', icon: '⚙️', color: '#6366f1' }
];

const seed = async () => {
  try {
    await mongoose.connect(process.env.MONGO_URI);
    console.log('✅ Connected to MongoDB');

    // Clear existing data
    await User.deleteMany({});
    await Category.deleteMany({});
    await Note.deleteMany({});
    console.log('🗑️  Cleared existing data');

    // Create admin
    const salt = await bcrypt.genSalt(12);
    const hashedPassword = await bcrypt.hash('admin123', salt);
    const admin = await User.create({
      name: 'Admin User',
      email: 'admin@notesapp.com',
      password: hashedPassword,
      role: 'admin',
      bio: 'Platform Administrator'
    });
    console.log('👤 Admin created: admin@notesapp.com / admin123');

    // Create sample students
    const studentPassword = await bcrypt.hash('student123', salt);
    const students = await User.insertMany([
      { name: 'Alice Johnson', email: 'alice@student.com', password: studentPassword, role: 'student', bio: 'CS enthusiast, loves algorithms' },
      { name: 'Bob Smith', email: 'bob@student.com', password: studentPassword, role: 'student', bio: 'Math major, passion for calculus' },
      { name: 'Carol Davis', email: 'carol@student.com', password: studentPassword, role: 'student', bio: 'Biology student, future doctor' }
    ]);
    console.log('👥 Sample students created');

    // Create categories
    const createdCategories = await Category.insertMany(categories);
    console.log(`📚 Created ${createdCategories.length} categories`);

    // Create sample notes (without real files, just metadata for demo)
    const sampleNotes = [
      {
        title: 'Introduction to Data Structures',
        description: 'Comprehensive notes on arrays, linked lists, stacks, queues, trees, and graphs with examples.',
        subject: 'Computer Science',
        topic: 'Data Structures',
        fileUrl: '/uploads/sample-ds.pdf',
        fileName: 'Data_Structures_Notes.pdf',
        fileType: 'pdf',
        fileSize: 1024000,
        uploadedBy: students[0]._id,
        likesCount: 45,
        commentsCount: 12,
        savesCount: 23,
        views: 320,
        tags: ['algorithms', 'CS', 'programming'],
        status: 'approved'
      },
      {
        title: 'Calculus Made Easy - Integration & Differentiation',
        description: 'Step-by-step guide to understanding integration and differentiation with solved examples.',
        subject: 'Mathematics',
        topic: 'Calculus',
        fileUrl: '/uploads/sample-calc.pdf',
        fileName: 'Calculus_Notes.pdf',
        fileType: 'pdf',
        fileSize: 2048000,
        uploadedBy: students[1]._id,
        likesCount: 62,
        commentsCount: 18,
        savesCount: 41,
        views: 510,
        tags: ['calculus', 'math', 'integration'],
        status: 'approved'
      },
      {
        title: 'Organic Chemistry Reactions',
        description: 'All important organic chemistry reactions, mechanisms, and reagents for exam preparation.',
        subject: 'Chemistry',
        topic: 'Organic Chemistry',
        fileUrl: '/uploads/sample-chem.pdf',
        fileName: 'Organic_Chemistry.pdf',
        fileType: 'pdf',
        fileSize: 1536000,
        uploadedBy: students[2]._id,
        likesCount: 38,
        commentsCount: 9,
        savesCount: 27,
        views: 245,
        tags: ['chemistry', 'organic', 'reactions'],
        status: 'approved'
      },
      {
        title: 'Machine Learning Fundamentals',
        description: 'Introduction to ML algorithms: Linear Regression, Decision Trees, Neural Networks, and more.',
        subject: 'Data Science',
        topic: 'Machine Learning',
        fileUrl: '/uploads/sample-ml.pdf',
        fileName: 'ML_Fundamentals.pdf',
        fileType: 'pdf',
        fileSize: 3072000,
        uploadedBy: students[0]._id,
        likesCount: 89,
        commentsCount: 31,
        savesCount: 67,
        views: 890,
        tags: ['ML', 'AI', 'data science'],
        status: 'approved'
      },
      {
        title: 'Classical Mechanics & Laws of Motion',
        description: "Newton's laws, energy, momentum, and rotational mechanics with practice problems.",
        subject: 'Physics',
        topic: 'Classical Mechanics',
        fileUrl: '/uploads/sample-physics.pdf',
        fileName: 'Classical_Mechanics.pdf',
        fileType: 'pdf',
        fileSize: 1800000,
        uploadedBy: students[1]._id,
        likesCount: 29,
        commentsCount: 7,
        savesCount: 19,
        views: 180,
        tags: ['physics', 'mechanics', 'newton'],
        status: 'approved'
      },
      {
        title: 'Microeconomics Principles',
        description: 'Supply and demand, market structures, consumer theory, and production theory explained.',
        subject: 'Economics',
        topic: 'Microeconomics',
        fileUrl: '/uploads/sample-econ.pdf',
        fileName: 'Microeconomics.pdf',
        fileType: 'pdf',
        fileSize: 1200000,
        uploadedBy: students[2]._id,
        likesCount: 21,
        commentsCount: 5,
        savesCount: 14,
        views: 135,
        tags: ['economics', 'microeconomics', 'market'],
        status: 'approved'
      }
    ];

    await Note.insertMany(sampleNotes);
    console.log(`📝 Created ${sampleNotes.length} sample notes`);
    console.log('\n🎉 Database seeded successfully!');
    console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
    console.log('Admin Login: admin@notesapp.com / admin123');
    console.log('Student Login: alice@student.com / student123');
    console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
    process.exit(0);
  } catch (err) {
    console.error('❌ Seed error:', err);
    process.exit(1);
  }
};

seed();
