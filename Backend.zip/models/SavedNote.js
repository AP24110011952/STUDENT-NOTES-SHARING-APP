const mongoose = require('mongoose');

const savedNoteSchema = new mongoose.Schema({
  userId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  noteId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Note',
    required: true
  }
}, { timestamps: true });

savedNoteSchema.index({ userId: 1, noteId: 1 }, { unique: true });

module.exports = mongoose.model('SavedNote', savedNoteSchema);
