const express = require('express');
const router = express.Router();
const { protect } = require('../middleware/auth');
const upload = require('../middleware/upload');
const {
  getAllNotes, getNoteById, uploadNote, updateNote, deleteNote, getMyNotes, getTrendingNotes
} = require('../controllers/notesController');
const {
  likeNote, unlikeNote, saveNote, unsaveNote, getSavedNotes, getComments, addComment, deleteComment
} = require('../controllers/interactionController');

// Optional auth middleware - attaches user if token exists but doesn't block
const optionalAuth = async (req, res, next) => {
  const jwt = require('jsonwebtoken');
  const User = require('../models/User');
  try {
    if (req.headers.authorization && req.headers.authorization.startsWith('Bearer')) {
      const token = req.headers.authorization.split(' ')[1];
      const decoded = jwt.verify(token, process.env.JWT_SECRET);
      req.user = await User.findById(decoded.id).select('-password');
    }
  } catch (e) { /* ignore */ }
  next();
};

// Public routes
router.get('/trending', getTrendingNotes);
router.get('/saved', protect, getSavedNotes);
router.get('/my-notes', protect, getMyNotes);
router.get('/', optionalAuth, getAllNotes);
router.get('/:id', optionalAuth, getNoteById);

// Protected routes
router.post('/', protect, upload.single('file'), uploadNote);
router.put('/:id', protect, updateNote);
router.delete('/:id', protect, deleteNote);

// Interaction routes
router.post('/:id/like', protect, likeNote);
router.delete('/:id/like', protect, unlikeNote);
router.post('/:id/save', protect, saveNote);
router.delete('/:id/save', protect, unsaveNote);
router.get('/:id/comments', getComments);
router.post('/:id/comments', protect, addComment);

// Comment delete
router.delete('/comments/:id', protect, deleteComment);

module.exports = router;
