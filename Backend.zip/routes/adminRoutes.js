const express = require('express');
const router = express.Router();
const { protect, adminOnly } = require('../middleware/auth');
const {
  getDashboardStats, getAllUsers, updateUserRole, deleteUser, getAllNotesAdmin, approveNote, deleteNoteAdmin
} = require('../controllers/adminController');
const { deleteComment } = require('../controllers/interactionController');

router.use(protect, adminOnly);

router.get('/stats', getDashboardStats);
router.get('/users', getAllUsers);
router.put('/users/:id/role', updateUserRole);
router.delete('/users/:id', deleteUser);
router.get('/notes', getAllNotesAdmin);
router.put('/notes/:id/approve', approveNote);
router.delete('/notes/:id', deleteNoteAdmin);
router.delete('/comments/:id', deleteComment);

module.exports = router;
